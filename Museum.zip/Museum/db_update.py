import pandas as pd
from sqlalchemy import create_engine

data = pd.read_excel('templates/static/tables/dbv2.xlsx')

data['am'] = data['am'].astype(int)
data['inventory'] = data['inventory'].astype(int)

engine = create_engine('sqlite:///exhibits.db', echo=True)
sqlite_connection = engine.connect()

data.to_sql('exhibits', sqlite_connection, if_exists='replace', index=False)
