// $('.menu').click (function(){
//     $(this).toggleClass('open');
// });