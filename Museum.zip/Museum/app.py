from flask import Flask, render_template
import os
import sqlite3


conn = sqlite3.connect('exhibits.db')  # database connection
c = conn.cursor()

app = Flask(__name__, template_folder='templates', static_folder="templates/static")

folder_path = "../Museum/templates"
count = 0


for file_name in os.listdir(folder_path):
    if file_name.startswith('item_'):
        count += 1


def get_data():
    conn = sqlite3.connect('exhibits.db')
    cur = conn.cursor()
    cur.execute('SELECT * FROM exhibits')
    data = cur.fetchall()
    conn.close()
    return data


@app.route('/')
@app.route("/index/")
@app.route("/index.html/")
def index():
    return render_template('/index.html')


@app.route('/')
@app.route("/table/")
@app.route("/table.html/")
def table():
    data = get_data()
    return render_template('/table.html', data=data)


@app.route('/')
@app.route("/contacts/")
@app.route("/contacts.html/")
def contacts():
    return render_template('/contacts.html')


@app.route('/')
@app.route("/example/")
@app.route("/example.html/")
def example():
    data = get_data()
    return render_template('/example.html', data=data)


@app.route('/')
@app.route(f"/item_1/")
@app.route(f"/item_1.html/")
def item1():
    data = get_data()
    return render_template('/item_1.html', data=data)


@app.route('/')
@app.route(f"/item_<int:item_number>/")
@app.route('/item_<int:item_number>.html')
def item_page(item_number):
    data = get_data()
    return render_template(f'/item_{item_number}.html', data=data)


if __name__ == '__main__':
    app.run(debug=False)
